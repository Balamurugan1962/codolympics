"""Score the factors of 36, one entry per line.

Each entry is worth its points if it divides 36 exactly and has not already
been given. Duplicates score nothing rather than scoring twice.
"""

FACTORS = {1, 2, 3, 4, 6, 9, 12, 18, 36}


def score(entries):
    seen = set()
    out = []
    for raw in entries:
        text = raw.strip()
        try:
            value = int(text)
        except ValueError:
            out.append((False, f"{text!r} is not a whole number"))
            continue
        if value in seen:
            out.append((False, "already listed"))
        elif value in FACTORS:
            seen.add(value)
            out.append((True, ""))
        else:
            out.append((False, f"{value} does not divide 36"))
    return out
