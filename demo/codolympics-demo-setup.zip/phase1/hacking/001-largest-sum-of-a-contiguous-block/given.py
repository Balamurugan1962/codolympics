import sys

data = sys.stdin.read().split()
n = int(data[0])
a = [int(x) for x in data[1:1 + n]]

best = 0
current = 0
for value in a:
    current += value
    if current < 0:
        current = 0
    if current > best:
        best = current

print(best)
