import sys

data = sys.stdin.read().split()
n, x = int(data[0]), int(data[1])
a = [int(v) for v in data[2:2 + n]]

lo, hi, found = 0, n - 1, -1
while lo <= hi:
    mid = (lo + hi) // 2
    if a[mid] == x:
        found = mid
        break
    if a[mid] < x:
        lo = mid + 1
    else:
        hi = mid - 1

if found == -1:
    print(0)
else:
    count = 1
    i = found - 1
    while i > 0 and a[i] == x:
        count += 1
        i -= 1
    j = found + 1
    while j < n and a[j] == x:
        count += 1
        j += 1
    print(count)
